<?php
include "config.php";

$error = "";
$success = isset($_GET["signup"]) && $_GET["signup"] === "success";

if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit();
}

if (isset($_POST["username"])) {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    if ($username === "" || $password === "") {
        $error = "Please fill in all fields.";
    } else {
        $hashedPassword = md5($password);
        $query = "SELECT id, username FROM users WHERE username = '$username' AND password = '$hashedPassword'";
        $result = mysqli_query($conn, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_array($result);
            $_SESSION["user_id"] = $row["id"];
            $_SESSION["username"] = $row["username"];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid username or password.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Smart Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="auth-wrapper">
        <div class="auth-box">
            <h2>Welcome Back</h2>
            <p class="subtitle">Log in to your Smart Expense Tracker</p>

            <?php 
           
            if ($success) { 
            ?>
                <div class="success-msg">Account created successfully! Please log in.</div>
            <?php 
            } 
            ?>

            <?php 
            if ($error != "") { 
            ?>
                <div class="error-msg"><?php echo $error; ?></div>
            <?php 
            } 
            ?>

            <form method="POST" action="login.php">
                <input type="text" name="username" placeholder="Username" required
                       value="<?php if(isset($_POST['username'])) echo $_POST['username']; ?>">
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Log In</button>
            </form>

            <div class="switch-link">
                Don't have an account? <a href="signup.php">Sign up</a>
            </div>
        </div>
    </div>
</body>
</html>