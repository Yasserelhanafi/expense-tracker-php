<?php
include "config.php";
include "auth_check.php";

$userId = $_SESSION["user_id"];
$error = "";


if (isset($_GET["id"])) {
    $id = $_GET["id"];
} else {
    $id = 0;
}


$query = "SELECT id, title, amount, category, income_date FROM income WHERE id = '$id' AND user_id = '$userId'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    header("Location: dashboard.php");
    exit();
}
$income = mysqli_fetch_array($result);


if (isset($_POST["title"])) {
    $title = trim($_POST["title"]);
    $amount = $_POST["amount"];
    $category = $_POST["category"];
    $date = $_POST["income_date"];

    if ($title === "" || $amount === "" || $date === "") {
        $error = "Please fill in all required fields.";
    } elseif (!is_numeric($amount) || $amount <= 0) {
        $error = "Amount must be a positive number.";
    } else {
     
        $updateQuery = "UPDATE income SET title = '$title', amount = '$amount', category = '$category', income_date = '$date' WHERE id = '$id' AND user_id = '$userId'";
        
        if (mysqli_query($conn, $updateQuery)) {
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Something went wrong. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Income - Smart Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="navbar">
        <h1>💰 Smart Expense Tracker</h1>
        <div class="user-info">
            <span>Hi, <strong><?php echo $_SESSION["username"]; ?></strong></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="form-box">
        <h2>Edit Income</h2>

        <?php 
        if ($error != "") { 
        ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php 
        } 
        ?>

        <form method="POST" action="edit_income.php?id=<?php echo $id; ?>">
            <label>Title</label>
            <input type="text" name="title" value="<?php echo $income[1]; ?>" required>

            <label>Amount</label>
            <input type="number" name="amount" step="0.01" min="0.01" value="<?php echo $income[2]; ?>" required>

            <label>Category</label>
            <select name="category">
                <option value="Salary" <?php if($income[3] == "Salary") echo "selected"; ?>>Salary</option>
                <option value="Freelance" <?php if($income[3] == "Freelance") echo "selected"; ?>>Freelance</option>
                <option value="Business" <?php if($income[3] == "Business") echo "selected"; ?>>Business</option>
                <option value="Gift" <?php if($income[3] == "Gift") echo "selected"; ?>>Gift</option>
                <option value="Investment" <?php if($income[3] == "Investment") echo "selected"; ?>>Investment</option>
                <option value="Other" <?php if($income[3] == "Other") echo "selected"; ?>>Other</option>
            </select>

            <label>Date</label>
            <input type="date" name="income_date" value="<?php echo $income[4]; ?>" required>

            <div class="form-actions">
                <button type="submit" class="btn-save">Update Income</button>
                <a href="dashboard.php" class="btn-cancel">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>