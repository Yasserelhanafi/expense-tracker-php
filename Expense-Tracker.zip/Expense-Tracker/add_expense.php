<?php
include "config.php";
include "auth_check.php";

$userId = $_SESSION["user_id"];
$error = "";


if (isset($_POST["title"])) {
    $title = trim($_POST["title"]);
    $amount = $_POST["amount"];
    $category = $_POST["category"];
    $date = $_POST["expense_date"];

    if ($title === "" || $amount === "" || $date === "") {
        $error = "Please fill in all required fields.";
    } elseif (!is_numeric($amount) || $amount <= 0) {
        $error = "Amount must be a positive number.";
    } else {
        $insertQuery = "INSERT INTO expenses (user_id, title, amount, category, expense_date) VALUES ($userId, '$title', $amount, '$category', '$date')";
        
        if (mysqli_query($conn, $insertQuery)) {
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Something went wrong. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Expense - Smart Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="navbar">
        <h1>💰 Smart Expense Tracker</h1>
        <div class="user-info">
            <span>Hi, <strong><?php echo $_SESSION["username"]; ?></strong></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="form-box">
        <h2>Add Expense</h2>

        <?php 
        if ($error != "") { 
        ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php 
        } 
        ?>

        <form method="POST" action="add_expense.php">
            <label>Title</label>
            <input type="text" name="title" placeholder="e.g. Groceries" required>

            <label>Amount</label>
            <input type="number" name="amount" step="0.01" min="0.01" placeholder="0.00" required>

            <label>Category</label>
            <select name="category">
                <option value="Food">Food</option>
                <option value="Transport">Transport</option>
                <option value="Bills">Bills</option>
                <option value="Shopping">Shopping</option>
                <option value="Health">Health</option>
                <option value="Entertainment">Entertainment</option>
                <option value="Other">Other</option>
            </select>

            <label>Date</label>
            <input type="date" name="expense_date" value="<?php echo date('Y-m-d'); ?>" required>

            <div class="form-actions">
                <button type="submit" class="btn-save">Save Expense</button>
                <a href="dashboard.php" class="btn-cancel">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>