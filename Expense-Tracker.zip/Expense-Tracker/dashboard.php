<?php
include "config.php";
include "auth_check.php";

$userId = $_SESSION["user_id"];


$expenseQuery = "SELECT id, title, amount, category, expense_date FROM expenses WHERE user_id = $userId ORDER BY expense_date DESC";
$expenses = mysqli_query($conn, $expenseQuery);

$incomeQuery = "SELECT id, title, amount, category, income_date FROM income WHERE user_id = $userId ORDER BY income_date DESC";
$incomeRows = mysqli_query($conn, $incomeQuery);


$totalExpenseQuery = "SELECT SUM(amount) AS total FROM expenses WHERE user_id = $userId";
$totalExpenseResult = mysqli_query($conn, $totalExpenseQuery);
$expenseRow = mysqli_fetch_array($totalExpenseResult);
$totalExpense = $expenseRow[0];
if ($totalExpense == "") {
    $totalExpense = 0;
}

$totalIncomeQuery = "SELECT SUM(amount) AS total FROM income WHERE user_id = $userId";
$totalIncomeResult = mysqli_query($conn, $totalIncomeQuery);
$incomeRow = mysqli_fetch_array($totalIncomeResult);
$totalIncome = $incomeRow[0];
if ($totalIncome == "") {
    $totalIncome = 0;
}

$balance = $totalIncome - $totalExpense;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Smart Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="navbar">
        <h1>💰 Smart Expense Tracker</h1>
        <div class="user-info">
            <span>Hi, <strong><?php echo $_SESSION["username"]; ?></strong></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">

        <div class="summary-cards">
            <div class="card income">
                <h3>Total Income</h3>
                <p>$<?php echo $totalIncome; ?></p>
            </div>
            <div class="card expense">
                <h3>Total Expenses</h3>
                <p>$<?php echo $totalExpense; ?></p>
            </div>
            <div class="card balance">
                <h3>Balance</h3>
                <p>$<?php echo $balance; ?></p>
            </div>
        </div>

        <div class="section">
            <div class="section-header">
                <h2>Income</h2>
                <a href="add_income.php" class="btn-add">+ Add Income</a>
            </div>

            <?php 
            if ($incomeRows && mysqli_num_rows($incomeRows) > 0) { 
            ?>
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    while ($row = mysqli_fetch_array($incomeRows)) { 
                    ?>
                    <tr>
                        <td><?php echo $row[1]; ?></td>
                        <td><span class="badge"><?php echo $row[3]; ?></span></td>
                        <td><?php echo $row[4]; ?></td>
                        <td>$<?php echo $row[2]; ?></td>
                        <td class="actions">
                            <a class="edit-link" href="edit_income.php?id=<?php echo $row[0]; ?>">Edit</a>
                            <a class="delete-link" href="delete_income.php?id=<?php echo $row[0]; ?>"
                               onclick="return confirm('Delete this income entry?');">Delete</a>
                        </td>
                    </tr>
                    <?php 
                    } 
                    ?>
                </tbody>
            </table>
            <?php 
            } else { 
            ?>
                <p class="empty-state">No income recorded yet. Add your first one!</p>
            <?php 
            } 
            ?>
        </div>

        <div class="section">
            <div class="section-header">
                <h2>Expenses</h2>
                <a href="add_expense.php" class="btn-add">+ Add Expense</a>
            </div>

            <?php 
            if ($expenses && mysqli_num_rows($expenses) > 0) { 
            ?>
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    while ($row = mysqli_fetch_array($expenses)) { 
                    ?>
                    <tr>
                        <td><?php echo $row[1]; ?></td>
                        <td><span class="badge"><?php echo $row[3]; ?></span></td>
                        <td><?php echo $row[4]; ?></td>
                        <td>$<?php echo $row[2]; ?></td>
                        <td class="actions">
                            <a class="edit-link" href="edit_expense.php?id=<?php echo $row[0]; ?>">Edit</a>
                            <a class="delete-link" href="delete_expense.php?id=<?php echo $row[0]; ?>"
                               onclick="return confirm('Delete this expense?');">Delete</a>
                        </td>
                    </tr>
                    <?php 
                    } 
                    ?>
                </tbody>
            </table>
            <?php 
            } else { 
            ?>
                <p class="empty-state">No expenses recorded yet. Add your first one!</p>
            <?php 
            } 
            ?>
        </div>

    </div>
</body>
</html>