<?php
include "config.php";
include "auth_check.php";

$userId = $_SESSION["user_id"];
$error = "";

if (isset($_GET["id"])) {
    $id = $_GET["id"];
} else {
    $id = 0;
}


$query = "SELECT id, title, amount, category, expense_date FROM expenses WHERE id = '$id' AND user_id = '$userId'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    header("Location: dashboard.php");
    exit();
}
$expense = mysqli_fetch_array($result);


if (isset($_POST["title"])) {
    $title = trim($_POST["title"]);
    $amount = $_POST["amount"];
    $category = $_POST["category"];
    $date = $_POST["expense_date"];

    if ($title === "" || $amount === "" || $date === "") {
        $error = "Please fill in all required fields.";
    } elseif (!is_numeric($amount) || $amount <= 0) {
        $error = "Amount must be a positive number.";
    } else {
    
        $updateQuery = "UPDATE expenses SET title = '$title', amount = '$amount', category = '$category', expense_date = '$date' WHERE id = '$id' AND user_id = '$userId'";
        
        if (mysqli_query($conn, $updateQuery)) {
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Something went wrong. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Expense - Smart Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="navbar">
        <h1>💰 Smart Expense Tracker</h1>
        <div class="user-info">
            <span>Hi, <strong><?php echo $_SESSION["username"]; ?></strong></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="form-box">
        <h2>Edit Expense</h2>

        <?php 
        if ($error != "") { 
        ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php 
        } 
        ?>

        <form method="POST" action="edit_expense.php?id=<?php echo $id; ?>">
            <label>Title</label>
            <input type="text" name="title" value="<?php echo $expense[1]; ?>" required>

            <label>Amount</label>
            <input type="number" name="amount" step="0.01" min="0.01" value="<?php echo $expense[2]; ?>" required>

            <label>Category</label>
            <select name="category">
                <option value="Food" <?php if($expense[3] == "Food") echo "selected"; ?>>Food</option>
                <option value="Transport" <?php if($expense[3] == "Transport") echo "selected"; ?>>Transport</option>
                <option value="Bills" <?php if($expense[3] == "Bills") echo "selected"; ?>>Bills</option>
                <option value="Shopping" <?php if($expense[3] == "Shopping") echo "selected"; ?>>Shopping</option>
                <option value="Health" <?php if($expense[3] == "Health") echo "selected"; ?>>Health</option>
                <option value="Entertainment" <?php if($expense[3] == "Entertainment") echo "selected"; ?>>Entertainment</option>
                <option value="Other" <?php if($expense[3] == "Other") echo "selected"; ?>>Other</option>
            </select>

            <label>Date</label>
            <input type="date" name="expense_date" value="<?php echo $expense[4]; ?>" required>

            <div class="form-actions">
                <button type="submit" class="btn-save">Update Expense</button>
                <a href="dashboard.php" class="btn-cancel">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>