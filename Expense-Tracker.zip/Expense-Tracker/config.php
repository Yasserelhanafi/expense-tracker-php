<?php

$host = "localhost";
$dbUser = "root";
$dbPass = "";
$dbName = "expense_tracker";


$conn = mysqli_connect($host, $dbUser, $dbPass, $dbName);

if (!$conn) {
    die("Something Went Wrong");
}


session_start();
?>