<?php
include "config.php";
include "auth_check.php";

$userId = $_SESSION["user_id"];


if (isset($_GET["id"])) {
    $id = $_GET["id"];

    $query = "DELETE FROM expenses WHERE id = '$id' AND user_id = '$userId'";
    mysqli_query($conn, $query);
}

header("Location: dashboard.php");
exit();
?>