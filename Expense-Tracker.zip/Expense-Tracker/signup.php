<?php
include "config.php";

$error = "";

if (isset($_POST["username"])) {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];
    $confirm  = $_POST["confirm_password"];

    if ($username === "" || $password === "") {
        $error = "Please fill in all fields.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $checkQuery = "SELECT id FROM users WHERE username = '$username'";
        $checkResult = mysqli_query($conn, $checkQuery);

        if ($checkResult && mysqli_num_rows($checkResult) > 0) {
            $error = "Username already taken.";
        } else {
            $hashedPassword = md5($password);
            $insertQuery = "INSERT INTO users (username, password) VALUES ('$username', '$hashedPassword')";
            
            if (mysqli_query($conn, $insertQuery)) {
                header("Location: login.php?signup=success");
                exit();
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up - Smart Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="auth-wrapper">
        <div class="auth-box">
            <h2>Create Account</h2>
            <p class="subtitle">Start tracking your expenses and income</p>

            <?php 
        
            if ($error != "") { 
            ?>
                <div class="error-msg"><?php echo $error; ?></div>
            <?php 
            } 
            ?>

            <form method="POST" action="signup.php">
                <input type="text" name="username" placeholder="Username" required
                       value="<?php if(isset($_POST['username'])) echo $_POST['username']; ?>">
                <input type="password" name="password" placeholder="Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                <button type="submit">Sign Up</button>
            </form>

            <div class="switch-link">
                Already have an account? <a href="login.php">Log in</a>
            </div>
        </div>
    </div>
</body>
</html>